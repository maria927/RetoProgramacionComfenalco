import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Parametros } from './parametros';
import {AppService} from './app.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],

})

export class AppComponent {

  isSubmit:boolean=false;
  error:string;
  title = 'matrizProject';
  mostrar = false;
  info: any [] = [];
  datos: Parametros = new Parametros();


  constructor(private service: AppService) 
  {
   
  }

  guardar(forma: NgForm)
  {
    this.isSubmit = true;
    if(this.isValid()){
      this.service.postCalcular(this.datos).subscribe(
        res=>{
          console.log(res);
          this.datos = res;
          this.mostrar = true;
         },
        error=>{
          alert("Ocurrió un error");
          console.error(error);
        }
      );
    }

   
    
  }
 
  isValid(): any {
    var content = this.datos.data.toString();
    this.error = undefined;
    if(content.length != (this.datos.alto * this.datos.ancho)){
      this.error = "el contenido de la matriz no coincide con la dimensión ("+ (this.datos.alto * this.datos.ancho)+")";
      return false;
    }

    return true;
  }

  sizeChange(event: string){
    try {
      var posiciones = event.split("-");
      this.datos.alto = parseInt(posiciones[0]);
      this.datos.ancho = parseInt(posiciones[1]);   
    
    } catch (error) {
      this.datos.alto = 0;
      this.datos.ancho= 0;
    }
   
  }




}
