export class Parametros{
    dimension: number;
   // matriznumerica: number;
    data: string="";
    operationiD: string;
    tipo: string;
    isNumeric:number;
    alto:number;
    ancho:number;
    stringReturn:any[];
    charReturn:any[];
    dataMatrix:any[];
    temporalReturn:any[];
}
