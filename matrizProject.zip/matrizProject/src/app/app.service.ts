import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders} from '@angular/common/http';
import { Parametros } from './parametros';
import { catchError, map, tap } from 'rxjs/operators';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
@Injectable({
  providedIn: 'root'
})


export class AppService {

  private url:string='http://localhost:8080/RetoREST/reto/operacioensservice/';

  constructor(private http: HttpClient) {
    
  }
  postCalcular(data:Parametros){
    return this.http.post<Parametros>(this.url, data, httpOptions).pipe(
      tap(_ => {}));
      
  }

 
}
